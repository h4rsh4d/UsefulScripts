<?php
//header("Debug: 0");
$filename = $_GET['doge'];
//echo "Headers:".$_SERVER[HTTP_ADMIN];
$validValues = array('Doge_Gym_Registration_Form.pdf');
//$blocked = array('/','file:/');
header("Pragma: public");
header("Expires: 0");
//header("Debug: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Type: application/force-download");
header("Content-Type: application/octet-stream");
header("Content-Type: application/download");
//header("Content-Disposition: attachment; filename=".basename($filename).";");
header("Content-Transfer-Encoding: binary");
header("Content-Length: ".filesize($filename));

if (in_array($filename, $validValues, true)) {
    //die("invalid 'page' value");
      header("Content-Disposition: attachment;       filename=".basename($filename).";");
      @readfile($filename);
}

//if(@strstr($filename,'file:/')){
//    die('LFI Attempt Detected');
      //@readfile($filename);
//}


//if(@strstr($filename,'/')){
//    die('LFI Attempt Detected');
      //@readfile($filename);
//}
$headerValue = $_SERVER['HTTP_ADMIN'];
if (isset($_SERVER['HTTP_ADMIN'])) {
   $userAgent = $_SERVER['HTTP_ADMIN'];
   //echo "User-Agent:" . $userAgent;
} else {
   //echo "User-Agent header is not set.";
   die("This Functionality only allowed to Admin");
}
if(preg_match('/[\/]/i', $filename)) {
      if(@strstr($filename,'data:/')){
    //die('LFI Attempt Detected');
      @readfile($filename);
      //die('Detected');
      }
      else {
      die('LFI Attempt Detected [We have fixed that issue :p]');
      }
}


@readfile($filename);
exit(0);
?>
